# Inscryption Booster Pack - Revised Edition

A set of small tweaks to cards from the base game. These tweaks are intended to improve the replayability of Act 1 by modifying some underpowered and overpowered options to have more situational value, as well as some small thematically interesting tweaks.

## What It Does

* The Wolf now evolves into an Alpha when given the Evolve sigil. It still does not have Evolve by default, so must be given it via sigil altar or a totem.
* The River Snapper now has the Sentry ability, causing it to take a small nip at any creature that comes too close. Once custom abilities are supported via JSON Loader, the Snapper will be tweaked further.
* Bees now have the "Brittle" ability, so they die after attacking once. This makes them less powerful as a side deck.
* Squirrels now have the "Mighty Leap" ability, allowing them to block flying attacks. This, combined with the change to bees, should mean that choosing between the two side decks is a more strategically interesting decision.
* The Squirrel tribe has been expanded into an actual multi-card tribe that incorporates rodents, tree-dwelling creatures, etc. The specific cards added to the tribe are:
    * Beaver
    * Field Mice
    * Mole
    * Mole Man
    * Opossum
    * Pack Rat
    * Rabbit
    * Rat King
    * River Otter
    * Skunk
    * Squirrel Ball (ported from Act 2)
    * Stoat

## Art Credits

* Squirrel Ball: WACriminal, utilizing the original game's squirrel art.

## Recommendation

It is recommended to install MADH95's Sigil Art Patch. Without it, the Squirrel Ball's sigil will just be a black square.