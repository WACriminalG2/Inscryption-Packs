# Inscryption Booster Pack - Unlimited Edition

A pack of 15 unthemed cards suited for use in Act 1.

## Art Credits

* Anteater -- Caro Asercion, Game-Icons.net
* Bald Eagle -- Hey Rabbit, The Noun Project
* Carrion Ant -- WACriminal
* Hedgehog -- UCI Draw Drawing Academy on YouTube
* Hippopotamus -- IconGeek26, The Noun Project
* Joey -- rahmat, The Noun Project
* Kangaroo -- Hey Rabbit, The Noun Project
* King Cobra -- Skoll, Game-Icons.net
* Llama -- Julian Roman, The Noun Project
* Mockingbird -- Lorc, Game-Icons.net
* Platypus -- parkjisun, The Noun Project
* Rabid Dog -- Amethyst Studio, The Noun Project
* Ring-Tailed Lemur -- Anniken & Andreas, The Noun Project
* St. Bernard -- Rvdutes
* Truffle Hog -- Handbook of Practical Cooking by Matilda Lees Dods, 1886